// Año actual
document.getElementById("year").textContent = new Date().getFullYear();

// Copiar email
const copyBtn = document.getElementById("copy-email");
const copyBadge = document.getElementById("copy-badge");

copyBtn.addEventListener("click", () => {
  navigator.clipboard.writeText("nicolas.huert4@gmail.com").then(() => {
    copyBadge.textContent = "¡Copiado!";
    copyBadge.style.backgroundColor = "#FF4D00";
    copyBadge.style.color = "#FFFFFF";
    copyBadge.style.borderColor = "#FF4D00";

    setTimeout(() => {
      copyBadge.textContent = "Copiar";
      copyBadge.style.backgroundColor = "";
      copyBadge.style.color = "";
      copyBadge.style.borderColor = "";
    }, 2000);
  });
});

// Filtro de habilidades
const filterButtons = document.querySelectorAll(".filter-btn");
const skillRows = document.querySelectorAll(".skill-row");

filterButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    filterButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");

    const selected = btn.getAttribute("data-filter");

    skillRows.forEach((row) => {
      if (selected === "all" || row.getAttribute("data-category") === selected) {
        row.classList.remove("hidden");
      } else {
        row.classList.add("hidden");
      }
    });
  });
});

// Sección activa en navegación
const sections = document.querySelectorAll(".section");
const navLinks = document.querySelectorAll(".nav-link");

window.addEventListener("scroll", () => {
  let current = "";

  sections.forEach((section) => {
    if (window.scrollY >= section.offsetTop - 140) {
      current = section.getAttribute("id");
    }
  });

  navLinks.forEach((link) => {
    link.classList.remove("active");
    if (link.getAttribute("href") === `#${current}`) {
      link.classList.add("active");
    }
  });
});